import React from "react";
import { acData } from "../data/ac";
import { useParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import { useCart } from "../context/CartContext";

const ACSingle = () => {
  const { id } = useParams();
  const { addToCart, cartItems } = useCart();

  // Ensure id is the correct type (number) by parsing it
  const productId = parseInt(id, 10);

  // Find the product based on the id
  const product = acData.find((item) => item.id === productId);

  if (!product) {
    return <div>Product not found</div>; // Optional: Handle missing product case
  }

  return (
    <>
      <Navbar />
      <div className="ind-section">
        <div className="ind-image">
          <img src={product.image} alt={product.model} />
        </div>
        <div className="ind-details space">
          <div className="ind-company">
            <h2>{product.company}</h2>
          </div>
          <div className="ind-model space">
            <h3>{product.model}</h3>
          </div>
          <div className="ind-price space">
            <h2>{product.price}</h2>
          </div>
          <div className="ind-desc space">
            <p>{product.description}</p>
          </div>
          <button onClick={() => addToCart(product)}>Add to Cart</button>
        </div>
      </div>
    </>
  );
};

export default ACSingle;
