// src/components/Navbar.jsx
import React from "react";
import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";

const Navbar = () => {
  const { cartItems } = useCart(); // Use the custom hook to access cart items

  return (
    <div className="navbar-section">
      <div className="navSection">
        <Link to="/" className="custom-link" aria-label="Go to homepage">
          <div className="title">
            <h2>E-Mart</h2>
          </div>
        </Link>

        <div className="search">
          <input type="text" placeholder="Search..." aria-label="Search products" />
        </div>

        <div className="user">
          <div className="user-detail">
            <Link to="/login">SignIn/SignUp</Link>
          </div>
        </div>

        <Link to="/cart" aria-label="Go to shopping cart">
          <div className="cart">
            Cart <span>{cartItems.length}</span> {/* Display cart item count */}
          </div>
        </Link>
      </div>

      <div className="subMenu">
        <ul>
          <Link to="/mobiles" className="custom-link" aria-label="Go to Mobiles page">
            <li>Mobiles</li>
          </Link>
          <Link to="/computers" className="custom-link" aria-label="Go to Computers page">
            <li>Computers</li>
          </Link>
          <Link to="/watch" className="custom-link" aria-label="Go to Watches page">
            <li>Watches</li>
          </Link>
          <Link to="/men" className="custom-link" aria-label="Go to Mens Wear page">
            <li>Mens Wear</li>
          </Link>
          <Link to="/woman" className="custom-link" aria-label="Go to Woman Wear page">
            <li>Woman Wear</li>
          </Link>
          <Link to="/furniture" className="custom-link" aria-label="Go to Furniture page">
            <li>Furniture</li>
          </Link>
          <Link to="/kitchen" className="custom-link" aria-label="Go to Kitchen page">
            <li>Kitchen</li>
          </Link>
          <Link to="/fridge" className="custom-link" aria-label="Go to Fridge page">
            <li>Fridge</li>
          </Link>
          <Link to="/books" className="custom-link" aria-label="Go to Books page">
            <li>Books</li>
          </Link>
          <Link to="/speakers" className="custom-link" aria-label="Go to Speakers page">
            <li>Speakers</li>
          </Link>
          <Link to="/tv" className="custom-link" aria-label="Go to TV page">
            <li>TV's</li>
          </Link>
          <Link to="/ac" className="custom-link" aria-label="Go to AC page">
            <li>AC</li>
          </Link>
        </ul>
      </div>
    </div>
  );
};

export default Navbar;
