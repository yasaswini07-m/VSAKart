import React from "react";
import { acData } from "../data/ac";

const AC = () => {
  const FirstFiveImages = acData.slice(0, 5);

  return (
    <>
      <h2>Air Conditioners</h2>
      <div className="proSection">
        {FirstFiveImages.map((item, index) => (
          <div className="imgBox" key={index}>
            <img className="proImage" src={item.image} alt={`AC ${index + 1}`} />
          </div>
        ))}
      </div>
    </>
  );
};

export default AC;
