import React from 'react';
import { tvData } from '../data/tv';

const TV = () => {
  const FirstFiveImages = tvData.slice(0, 5);

  return (
    <>
      <div className="proTitle">
        <h2>TV</h2>
      </div>
      <div className="proSection">
        {FirstFiveImages.map((item, index) => (
          <div className="imgBox" key={index}>
            <img className="proImage" src={item.image} alt={`TV ${index + 1}`} />
          </div>
        ))}
      </div>
    </>
  );
};

export default TV;
