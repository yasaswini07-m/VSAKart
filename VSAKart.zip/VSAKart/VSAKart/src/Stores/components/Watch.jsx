import React from 'react';
import { watchData } from '../data/watch'; // Ensure the correct path to watchData

const Watch = () => {
  // Extracting the first five items from watchData
  const FirstFiveImages = watchData.slice(0, 5);

  return (
    <>
      {/* Title Section */}
      <div className="proTitle">
        <h2>Watch</h2>
      </div>

      {/* Product Section */}
      <div className="proSection">
        {FirstFiveImages.map((item, index) => (
          <div className="imgBox" key={index}>
            {/* Displaying each product image */}
            <img className="proImage" src={item.image} alt={`Watch ${index + 1}`} />
          </div>
        ))}
      </div>
    </>
  );
};

export default Watch;
