// import React from 'react';

// import {computerData} from '../data/computers'

// const Computers=()=>{
//     const FirstFiveImages=computerData.slice(0,5)
//     return (
//         <>
//     <h2> Computers </h2>
//         <div className='proSection'>
//              {
//              FirstFiveImages.map((item)=>{
//             return(
//                 <div className='imgBox'> 
//                <img className='proImage' src={item.image} alt="" />

//                 </div>
//             )

//         })
//         }  
//         </div></>
//     )
// }

// export default Computers;

import React from "react";
import { kitchenData } from "../data/kitchen";
import Navbar from "../components/Navbar";

const KitchenPage = () => {
  if (!kitchenData || kitchenData.length === 0) {
    return <div>No kitchen data available.</div>;
  }

  return (
    <>
      <Navbar />
      <div className="pageSection">
        {kitchenData.map((item) => (
          <div key={item.id}>
            <div className="pageImage">
              <img
                src={item.image || "/default-image.jpg"}
                alt={item.model || "Kitchen"}
              />
            </div>
            <div className="proModel">
              {item.company}, {item.model}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default KitchenPage;
