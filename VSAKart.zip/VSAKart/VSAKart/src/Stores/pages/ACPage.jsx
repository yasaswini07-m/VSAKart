import React from "react";
import { acData } from '../data/ac';
import Navbar from "../components/Navbar";

const ACPage = () => {
  if (!acData || acData.length === 0) {
    return <div>No AC data available.</div>;  // Handling case if mobileData is empty or not defined
  }

  return (
    <>
    <Navbar />
    <div className="pageSection">
      {acData.map((item) => {  // Ensure there is valid data here
        return (
          <div key={item.id}>
            <div className="pageImage">
              <img src={item.image || '/default-image.jpg'} alt={item.product || 'AC'} /> {/* Fallback to default image */}
            </div>
            <div className="proModel">
                {item.company},{item.model}
            </div>
          </div>
        );
      })}
    </div>
    </>
  );
};

export default ACPage;
