

import React from "react";
import { fridgeData } from "../data/fridge";
import Navbar from "../components/Navbar";

const FridgePage = () => {
  if (!fridgeData || fridgeData.length === 0) {
    return <div>No fridge data available.</div>;
  }

  return (
    <>
      <Navbar />
      <div className="pageSection">
        {fridgeData.map((item) => (
          <div key={item.id}>
            <div className="pageImage">
              <img
                src={item.image || "/default-image.jpg"}
                alt={item.model || "Fridge"}
              />
            </div>
            <div className="proModel">
              {item.company}, {item.model}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default FridgePage;
