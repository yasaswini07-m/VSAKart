import React from "react";
import { womanData } from "../data/woman"; // Adjusted path
import Navbar from "../components/Navbar";

const WomanPage = () => {
  if (!womanData || womanData.length === 0) {
    return <div>No woman data available.</div>; // Handle empty or missing data
  }

  return (
    <>
      <Navbar />
      <div className="pageSection">
        {womanData.map((item) => (
          <div key={item.id}>
            <div className="pageImage">
              <img
                src={item.image || "/default-image.jpg"} // Fallback to default image
                alt={item.model || "Woman Product"} // Fallback alt text
              />
            </div>
            <div className="proModel">
              {item.company}, {item.model}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default WomanPage;
