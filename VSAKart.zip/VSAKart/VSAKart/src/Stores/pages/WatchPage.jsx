import React from "react";
import { watchData } from "../data/watch";
import Navbar from "../components/Navbar";

const WatchPage = () => {
  if (!watchData || watchData.length === 0) {
    return <div>No watch data available.</div>;
  }

  return (
    <>
      <Navbar />
      <div className="pageSection">
        {watchData.map((item) => (
          <div key={item.id}>
            <div className="pageImage">
              <img
                src={item.image || "/default-image.jpg"}
                alt={item.product || "Watch"}
              />
            </div>
            <div className="proModel">
              {item.company}, {item.model}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default WatchPage;
