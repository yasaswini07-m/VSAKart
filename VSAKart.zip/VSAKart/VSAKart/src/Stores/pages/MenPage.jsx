import React from "react";
import { menData } from "../data/men";
import Navbar from "../components/Navbar";

const MenPage = () => {
  if (!menData || menData.length === 0) {
    return <div>No Men data available.</div>;
  }

  return (
    <>
      <Navbar />
      <div className="pageSection">
        {menData.map((item, index) => (
          <div key={item.id || index}>
            <div className="pageImg">
              <img
                src={item.image || "/default-image.jpg"}
                alt={item.model || "men"}
              />
            </div>
            <div className="proModel">
              {item.company}, {item.model}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default MenPage;
